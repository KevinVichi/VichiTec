import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LogoComponent } from './componentes/logo/logo.component';
import { HeaderComponent } from './componentes/header/header.component';
import { CustomInputComponent } from './componentes/custom-input/custom-input.component';
import { IonicModule } from '@ionic/angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddUpdateComponent } from './componentes/add-update/add-update.component';

@NgModule({
  declarations: [
    LogoComponent,
    HeaderComponent,
    CustomInputComponent,
    AddUpdateComponent,
  ],
  imports: [CommonModule, IonicModule, FormsModule, ReactiveFormsModule],
  exports: [
    LogoComponent,
    HeaderComponent,
    CustomInputComponent,
    AddUpdateComponent,
    FormsModule,
    ReactiveFormsModule,
  ],
})
export class SharedModule {}
