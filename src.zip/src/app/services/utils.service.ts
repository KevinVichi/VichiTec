import { inject, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import {
  AlertController,
  AlertOptions,
  LoadingController,
  LoadingOptions,
  ModalController,
  ModalOptions,
  ToastController,
  ToastOptions,
} from '@ionic/angular';

@Injectable({
  providedIn: 'root',
})
export class UtilsService {
  createModal(arg0: {
    component: HTMLVideoElement;
    buttons: (
      | { text: string; handler: () => void }
      | { text: string; role: string; handler: () => void }
    )[];
  }) {
    throw new Error('Method not implemented.');
  }
  alertCtrl = inject(AlertController);
  toastCtrl = inject(ToastController);
  loadingCtrl = inject(LoadingController);
  modalCtrl = inject(ModalController);
  router = inject(Router);
  toastController = inject(ToastController);

  //  Alert
  presentAlert(opts: AlertOptions) {
    return this.alertCtrl.create(opts);
  }

  // Loading
  presentLoading() {
    return this.loadingCtrl.create({ spinner: 'crescent' });
  }

  // Toast
  async presentToast(opts: ToastOptions) {
    const toast = await this.toastCtrl.create(opts);
    toast.present();
  }

  // Navigate
  routerLink(url: string) {
    this.router.navigateByUrl(url);
  }

  // Add Item LocalStorage
  saveInLocalStorage(key: string, value: any) {
    return localStorage.setItem(key, JSON.stringify(value));
  }

  // Get Item LocalStorage
  // Get Item LocalStorage
  getFromLocalStorage(key: string) {
    const item = localStorage.getItem(key);
    try {
      return JSON.parse(item);
    } catch (e) {
      console.error(
        `Error parsing JSON from localStorage for key "${key}":`,
        e
      );
      return null;
    }
  }

  //present modal
  async presentModal(opts: ModalOptions) {
    const modal = await this.modalCtrl.create(opts);
    await modal.present();

    const { data } = await modal.onWillDismiss();
    if (data) {
      return data;
    }
  }

  dismissModal(data?: any) {
    this.modalCtrl.dismiss(data);
  }

  async takePicture(promptLabelHeader: string) {
    return await Camera.getPhoto({
      quality: 90,
      allowEditing: true,
      resultType: CameraResultType.DataUrl,
      source: CameraSource.Prompt,
      promptLabelHeader,
      promptLabelPhoto: 'Selecciona una imagen',
      promptLabelPicture: 'Toma una foto',
    });
  }

  //
  async presentAlertConfirm(header: string, message: string): Promise<boolean> {
    // Implementation of the method

    // This is a placeholder implementation, you need to replace it with the actual implementation

    return Promise.resolve(confirm(`${header}\n${message}`));
  }

  // ============ Alert ===========

  async showToast(op?: ToastOptions) {
    const toast = await this.toastController.create(op);
    toast.present();
  }
}
