import { Component, inject } from '@angular/core';
import { Product } from 'src/app/models/product.interface';
import { FirebaseService } from 'src/app/services/firebase.service';
import { UtilsService } from 'src/app/services/utils.service';
import { AddUpdateComponent } from 'src/app/shared/componentes/add-update/add-update.component';
import { User } from 'src/app/models/user.interface';
import { orderBy } from 'firebase/firestore';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage {
  product: Product;
  firebaseSvc = inject(FirebaseService);
  utilsSvc = inject(UtilsService);
  alertCtrl = inject(AlertController);

  products: Product[] = [];
  loading: boolean = false;

  user(): User {
    const user = this.utilsSvc.getFromLocalStorage('user');
    console.log('User:', user);
    return user;
  }

  ngOnInit() {
    this.getProducts();
  }

  async addUpdateProduct(product?: Product) {
    let success = await this.utilsSvc.presentModal({
      component: AddUpdateComponent,
      cssClass: 'add-update-modal',
      componentProps: { product },
    });

    if (success) {
      this.getProducts();
    }
  }

  // ====== Obtener productos =====
  getProducts() {
    let path = `users/${this.user().uid}/products`;
    console.log(path);
    this.loading = true;

    let query = [orderBy('soldUnits', 'desc')];

    let sub = this.firebaseSvc.getCollectionData(path, query).subscribe({
      next: (res: any) => {
        console.log(res);
        this.products = res;
        this.loading = false;
        sub.unsubscribe();
      },
      error: (err) => {
        console.error('Error fetching products:', err);
        this.loading = false;
      },
    });
  }

  // ====== Obtener ganancias =====
  getProfits() {
    return this.products.reduce(
      (index, product) => index + product.price * product.soldUnits,
      0
    );
  }

  async confirmDeleteProduct(product: Product) {
    const alert = await this.alertCtrl.create({
      header: 'Confirmar eliminación',
      message: `¿Estás seguro de que deseas eliminar el producto "${product.name}"?`,
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
        },
        {
          text: 'Eliminar',
          handler: () => {
            this.deleteProduct(product);
          },
        },
      ],
    });

    await alert.present();
  }
  async deleteProduct(product: Product) {
    const path = `users/${this.user().uid}/products/${product.id}`;
    const exists = await this.firebaseSvc.documentExists(path);

    if (exists) {
      const imageUrl = product.image;

      // Eliminar el documento de Firestore
      this.firebaseSvc
        .deleteDocument(path)
        .then(async () => {
          // Eliminar la imagen del Storage
          await this.firebaseSvc.deleteImage(imageUrl);

          // Notificar al usuario
          this.utilsSvc.showToast({
            message: 'Producto eliminado con éxito',
            duration: 2000,
            position: 'top',
          });

          // Recargar la lista de productos
          this.getProducts();
        })
        .catch((error) => {
          this.utilsSvc.showToast({
            message: 'Error al eliminar el producto',
            duration: 2000,
            position: 'top',
          });
          console.error(error);
        });
    } else {
      this.utilsSvc.showToast({
        message: 'El producto no existe',
        duration: 2000,
        position: 'top',
      });
    }
  }
}
